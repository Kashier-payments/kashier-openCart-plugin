<?php
// Heading
$_['heading_title'] = 'Kashier';

// Text
$_['text_title'] = 'Pay with Kashier';
$_['text_card'] = 'Credit / Debit Card';
$_['text_wallet'] = 'Mobile Wallet';
$_['text_installments'] = 'Bank Installments';
$_['text_bnpl'] = 'Buy Now, Pay Later';
$_['text_loading'] = 'Loading...';

// Button
$_['button_confirm'] = 'Confirm Order';

// Error
$_['text_transaction_id'] = 'Transaction ID: %s';
$_['text_merchant_id'] = 'Merchant Order ID: %s';
$_['error_order'] = 'No order ID in the session!';
$_['error_payment'] = 'Payment failed, please try again.';
$_['error_invalid_order'] = 'Invalid Order ID!';
