<?php
namespace Opencart\Catalog\Controller\Extension\Kashier\Payment;

use Opencart\Catalog\Model\Extension\Kashier\Payment\kashier as PaymentKashier;

class kashier extends \Opencart\System\Engine\Controller
{
    /**
     * Index
     *
     * @return string
     */
    public function index(): string
    {
        $this->load->language('extension/kashier/payment/kashier');

        $data['language'] = $this->config->get('config_language');

        return $this->load->view('extension/kashier/payment/kashier', $data);
    }

    /**
     * Confirm
     *
     * Validates order and prepares payment metadata
     *
     * @return void
     */
    // public function confirm(): void
    // {

    // 	$curl = curl_init();

    // 	curl_setopt_array($curl, array(
    // 	CURLOPT_URL => 'https://test-api.kashier.io/v3/payment/sessions',
    // 	CURLOPT_RETURNTRANSFER => true,
    // 	CURLOPT_ENCODING => '',
    // 	CURLOPT_MAXREDIRS => 10,
    // 	CURLOPT_TIMEOUT => 0,
    // 	CURLOPT_FOLLOWLOCATION => true,
    // 	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    // 	CURLOPT_CUSTOMREQUEST => 'POST',
    // 	CURLOPT_POSTFIELDS =>'{
    // 		"maxFailureAttempts": 3,
    // 		"paymentType": "credit",
    // 		"amount": "1.00",
    // 		"currency": "EGP",
    // 		"order": "awsszsssd",
    // 		"merchantId":"MID-24358-575",
    // 		"merchantRedirect": "https://example.com/redirect",
    // 		"display": "en",
    // 		"type": "one-time",

    // 		"allowedMethods": "card,wallet",
    // 		"redirectMethod": null,
    // 		"iframeBackgroundColor": "#FFFFFF",
    // 		"metaData": {
    // 			"customKey": "customValue",
    // 			"displayNotes": {"ahmed": "test", "test2": "test3"}
    // 		},
    // 		"failureRedirect": false,
    // 		"brandColor": "#FF5733",
    // 		"defaultMethod": "card",

    // 		"description": "Payment for order ORD123456",
    // 		"manualCapture": false,
    // 		"customer": {
    // 			"email": "John Doe",
    // 			"reference": "ahmed"
    // 		},
    // 		"saveCard": "optional",
    // 		"retrieveSavedCard": true,
    // 		"interactionSource": "ECOMMERCE",
    // 		"enable3DS": true,

    // 		"serverWebhook": "https://webhook.site/512c3b8c-7ad5-4361-ae92-549971e30462",
    // 		"notes": "Special handling required"
    // 	}',
    // 	CURLOPT_HTTPHEADER => array(
    // 		'Authorization: 8b3e3eb408c499e3b9427a1545fee0ee$9088f85e9ec58baa65cb7eac35b73bcaef1bc5e532d5df7e7d67f42cdd4b38182027caca36b25fff37359a6825fe9752',
    // 		'api-key: 6ca3f4c9-caf3-4b45-bb8b-e39841e6031b',
    // 		'Content-Type: application/json'
    // 	),
    // 	));

    // 	$response = curl_exec($curl);

    // 	curl_close($curl);
    // 	echo $response;
    // 	$this->log->write('payment session response: ' . print_r($response,true));

    // // 	$this->load->language('extension/kashier/payment/kashier');

    // // 	$json = [];

    // // 	if (isset($this->session->data['order_id'])) {
    // // 		$order_id = $this->session->data['order_id'];
    // // 	}
    // // 	else {
    // // 		$order_id = 0;
    // // 	}

    // // 	if (!$order_id) {
    // // 		$json['error']['warning'] = $this->language->get('error_order');
    // // 	}

    // // 	if (!$json) {
    // // 		$this->load->model('checkout/order');

    // // 		$order_info = $this->model_checkout_order->getOrder($order_id);

    // // 		// Determine which sub-method was selected (e.g., kashier.card)
    // // 		$method_code = $this->session->data['payment_method']['code'];
    // // 		$sub_method = substr(strrchr($method_code, '.'), 1);

    // // 		// Kashier Integration Logic
    // // 		$merchant_id = $this->config->get('payment_kashier_mid');
    // // 		$test_mode = $this->config->get('payment_kashier_mode');

    // // 		if ($test_mode) {
    // // 			$api_key = $this->config->get('payment_kashier_test_api_key');
    // // 			$secret_key = $this->config->get('payment_kashier_test_secret_key');
    // // 		}
    // // 		else {
    // // 			$api_key = $this->config->get('payment_kashier_live_api_key');
    // // 			$secret_key = $this->config->get('payment_kashier_live_secret_key');
    // // 		}

    // // 		// Simulation of preparing request
    // // 		$data = [
    // // 			'merchantId' => $merchant_id,
    // // 			'amount' => $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false),
    // // 			'currency' => $order_info['currency_code'],
    // // 			'orderId' => $order_id,
    // // 			'subMethod' => $sub_method
    // // 		];

    // // 		if ($this->config->get('payment_kashier_debug')) {
    // // 			$this->log->write('Kashier Request: ' . print_r($data, true));
    // // 		}

    // // 		// In a real implementation, you would generate a token or redirect URL here.
    // // 		// For now, we simulate a successful redirect to a success page.

    // // 		// $this->model_checkout_order->addHistory($order_id, $this->config->get('config_order_status_id'), 'Kashier Payment Initiated', true);

    // // 		$json['redirect'] = $this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true);
    // // 	}

    // // 	$this->response->addHeader('Content-Type: application/json');
    // // 	$this->response->setOutput(json_encode($json));
    // }

    public function confirm(): void
    {
        $this->load->language('extension/kashier/payment/kashier');
        $json = [];

        if (!isset($this->session->data['order_id'])) {
            $json['error']['warning'] = $this->language->get('error_order');
        } else {
            $order_id = $this->session->data['order_id'];
            $this->load->model('checkout/order');
            $order_info = $this->model_checkout_order->getOrder($order_id);

            if (!$order_info) {
                $json['error']['warning'] = $this->language->get('error_order');
            } else {
                // Build request payload
                $amount = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
                $query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "kashier_merchant_configs`");
                $row = $query->row;
                $payload = [
                    "maxFailureAttempts" => 3,
                    "paymentType" => "credit",
                    "amount" => (string) $amount,
                    // "currency" => $order_info['currency_code'],
                    "currency" => "egp",
                    "order" => "ORD-12345-" . $order_id,
                    "merchantId" => $row["mid"],
                    "merchantRedirect" => $this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true),
                    "display" => "en",
                    "type" => "one-time",
                    "allowedMethods" => "card,wallet",
                    "description" => "Payment for order ORD" . $order_id,
                    "manualCapture" => false,
                    "customer" => [
                        "email" => $order_info['email'],
                        "reference" => $order_info['email']
                    ],
                    "enable3DS" => true,
                    "serverWebhook" => "https://your-webhook-url.example.com",
                ];
                $this->log->write("test_secret_key" . $row['test_secret_key']);
                $this->log->write("test_api_key" . $row['test_api_key']);
                $ch = curl_init(PaymentKashier::TEST_API_BASE_URL . '/payment/sessions');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, [
                    'Authorization: ' . "be3b860e8cf60e22ab7dec816977489f$1e7ed110d924ebbb20c6598818caa2ade0f991bf898e0ba2775bc30bd99d884dfdc162323b3684e2ca87b63de6c9404d",
                    'api-key: ' . $row['test_api_key'],
                    'Content-Type: application/json'
                ]);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
                $this->log->write("ch" . print_r($payload, true));

                $response = curl_exec($ch);
                curl_close($ch);

                $this->log->write('Kashier payment session response: ' . $response);

                $result = json_decode($response, true);

                if (!empty($result['sessionUrl'])) {
                    // Return redirect URL to frontend
                    $json['redirect'] = $result['sessionUrl'];

                    // Optional: mark order as "payment initiated"
                    $this->model_checkout_order->addHistory($order_id, $this->config->get('config_order_status_id'), 'Kashier Payment Initiated', true);
                } else {
                    $json['error']['warning'] = 'Unable to initiate payment. Please try again.';
                }
            }
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

    /**
     * Callback
     *
     * Handles response from Kashier
     *
     * @return void
     */
    public function callback(): void
    {
        if (isset($this->request->get['paymentStatus']) && $this->request->get['paymentStatus'] == 'SUCCESS') {
            $order_id = $this->request->get['orderId'];

            $this->load->model('checkout/order');
            $this->model_checkout_order->addHistory($order_id, $this->config->get('payment_kashier_order_status_id'), 'Kashier Payment Successful', true);

            $this->response->redirect($this->url->link('checkout/success', '', true));
        } else {
            $this->response->redirect($this->url->link('checkout/failure', '', true));
        }
    }
}
