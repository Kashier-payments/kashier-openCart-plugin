<?php
namespace Opencart\Catalog\Model\Extension\Kashier\Payment;
/**
 * Kashier
 *
 * Can be called from $this->load->model('extension/kashier/payment/kashier');
 *
 * @package Opencart\Catalog\Model\Extension\Kashier\Payment
 */
class kashier extends \Opencart\System\Engine\Model
{
	const TEST_API_BASE_URL="https://test-api.kashier.io/v3";
	const LIVE_API_BASE_URL="https://api.kashier.io/v3";
	const LIVE_FEP_BASE_URL="https://fep.kashier.io/v3";
	const TEST_FEP_BASE_URL="https://test-fep.kashier.io/v3";
	/**
	 * Get Methods
	 *
	 * @param array $address
	 * @return array
	 */
	public function getMethods(array $address): array
	{
		$this->log->write('Kashier getMethods called. Status: ' . $this->config->get('payment_kashier_status'));
		$this->load->language('extension/kashier/payment/kashier');
		$status = $this->config->get('payment_kashier_status');

		// You can add geo zone checks here if needed, similar to the credit_card example

		$method_data = [];

		if ($status) {
			$option_data = [];
			$this->log->write('status is true :'.$status);
			// Sub-methods logic
			$methods = [
				'card' => $this->language->get('text_card'),
				'wallet' => $this->language->get('text_wallet'),
				'installments' => $this->language->get('text_installments'),
				'bnpl' => $this->language->get('text_bnpl')
			];
			$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "kashier_merchant_configs`");
			$row = $query->row;
			
			$option_data = [];

			// map keys to titles (adjust titles as needed)
			$methods = [
				'bank_installments_enabled' => 'Bank Installments',
				'card_enabled' => 'Card Payments',
				'wallet_enabled' => 'Wallet',
				'bnpls_enabled' => 'BNPL'
			];

			foreach ($methods as $key => $title) {
				if (!empty($row[$key]) && (int)$row[$key] === 1) {
					$option_data[$key] = [
						'code' => 'kashier.' . $key,
						'name' => $title
					];
				}
			}

			$this->log->write('option_data: ' . print_r($option_data, true));

			if ($this->config->get('payment_kashier_debug')) {
				$this->log->write('Kashier Option Data: ' . print_r($option_data, true));
			}

			if ($option_data) {
				$method_data = [
					'code' => 'kashier',
					'name' => $this->language->get('heading_title'),
					'option' => $option_data,
					'sort_order' => $this->config->get('payment_kashier_sort_order')
				];
			}
		}
		$this->log->write('Kashier getMethods called. Status: ' . print_r($method_data,true));
		return $method_data;
	}

	/**
	 * Validate Signature
	 *
	 * @param string $queryString
	 * @param string $secret
	 * @return string
	 */
	public function validateSignature($payload, $secret)
    {
        return hash_hmac('sha256',$payload, $secret, false);
    }

	/**
	 * Add Order History
	 *
	 * @param int $order_id
	 * @param int $order_status_id
	 * @param string $comment
	 * @return void
	 */
	 public function addOrderHistory($order_id, $order_status_id, $comment = ''){
		try{
			$this->load->model('checkout/order');
			$this->model_checkout_order->addHistory($order_id, $order_status_id, $comment);
		} catch(\Exception $e){
		}
	}
	/**
	 * Get Order Histories
	 *
	 * @param int $order_id
	 * @param int $start
	 * @param int $limit
	 * @return array
	 */
    public function getOrderHistories($order_id, $start = 0, $limit = 10)
    {
        if ($start < 0) {
            $start = 0;
        }

        if ($limit < 1) {
            $limit = 10;
        }

        $query = $this->db->query("SELECT oh.date_added, oh.order_status_id, os.name AS status, oh.comment, oh.notify FROM " . DB_PREFIX . "order_history oh LEFT JOIN " . DB_PREFIX . "order_status os ON oh.order_status_id = os.order_status_id WHERE oh.order_id = '" . (int) $order_id . "' AND os.language_id = '" . (int) $this->config->get('config_language_id') . "' ORDER BY oh.date_added DESC LIMIT " . (int) $start . "," . (int) $limit);

        return $query->rows;
    }

	/**
	 * Pre Redirect
	 *
	 * @param array $data
	 * @return void
	 */
	public function preRedirect(array $data): void
	{
		$this->load->language('extension/kashier/payment/kashier');

		if (isset($data['payment_status']) && $data['payment_status'] !== 'SUCCESS') {
			$this->session->data['error'] = !empty($this->session->data['error']) ? $this->session->data['error'] : $this->language->get('error_payment');
		}
	}
}
