/**
	 * Callback
	 *
	 * Handles response from Kashier (both Webhook and Redirect)
	 *
	 * @return void
	 */
	public function callback(): void
	{
		$this->load->language('extension/kashier/payment/kashier');
		$this->load->model('extension/kashier/payment/kashier');
		$this->load->model('checkout/order');

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "kashier_merchant_configs` ORDER BY `date_added` DESC LIMIT 1");
		$config = $query->row;

		if (!$config) {
			$this->log->write('Kashier Callback Error: Merchant configuration not found.');
			return;
		}

		$isTestMode = ((int) $config['test_mode'] === 1);
		$secret = $isTestMode ? $config['test_secret_key'] : $config['live_secret_key'];

		if ($this->request->server['REQUEST_METHOD'] === 'POST') {
			$this->log->write('Kashier Webhook Received');

			$json_data = json_decode(file_get_contents('php://input'), true);
			$this->log->write("json_data",$json_data);
			if (!$json_data || !isset($json_data['data']) || !isset($json_data['event'])) {
				$this->log->write('Kashier Webhook Error: Invalid JSON data.');
				return;
			}

			$data_obj = $json_data['data'];
			$event = $json_data['event'];

			// Signature Validation
			$data = [];
			foreach ($data_obj['signatureKeys'] as $key) {
				$data[$key] = $data_obj[$key];
			}

			$queryString = http_build_query($data, '', '&', PHP_QUERY_RFC3986);
			$signature = $this->model_extension_kashier_payment_kashier->validateSignature($queryString, $secret);
			$kashierSignature = $this->request->server['HTTP_X_KASHIER_SIGNATURE'] ?? '';

			if ($signature !== $kashierSignature) {
				$this->log->write('Kashier Webhook Error: HMAC Failed to validate.');
				return;
			}

			// Extract Order ID
			$merchantOrderId = $data_obj['merchantOrderId'] ?? '';
			$order_id = (int) str_replace('ORD-9879-', '', $merchantOrderId);
			$this->log->write("order_id" . $order_id);
			$order_info = $this->model_checkout_order->getOrder($order_id);

			if ($order_info) {
				if ($event === 'pay') {
					if (strtoupper($data_obj['status']) === 'SUCCESS') {
						$order_status_id = $this->config->get('payment_kashier_processed_status_id');

						// Check if already updated
						$histories = $this->model_extension_kashier_payment_kashier->getOrderHistories($order_id, 0, 100);
						foreach ($histories as $history) {
							if ((int) $history['order_status_id'] === (int) $order_status_id) {
								$this->log->write("Kashier Webhook: Order $order_id already updated to processed status.");
								return;
							}
						}

						$comment = sprintf($this->language->get('text_transaction_id'), $data_obj['transactionId'] ?? '') . '<br/>' . sprintf($this->language->get('text_merchant_id'), $merchantOrderId);
						$this->model_extension_kashier_payment_kashier->addOrderHistory($order_id, $order_status_id, $comment);
					} else {
						$order_status_id = $this->config->get('payment_kashier_failed_status_id');
						$this->model_extension_kashier_payment_kashier->addOrderHistory($order_id, $order_status_id);
					}
				} else if ($event === 'refund') {
					if (strtoupper($data_obj['status']) === 'SUCCESS') {
						$comment = sprintf($this->language->get('text_transaction_id'), $data_obj['transactionId'] ?? '') . '<br/>' . sprintf($this->language->get('text_merchant_id'), $merchantOrderId);
						$order_status_id = $this->config->get('payment_kashier_refunded_status_id');
						$this->model_extension_kashier_payment_kashier->addOrderHistory($order_id, $order_status_id, $comment);
					}
				}
			} else {
				$this->log->write("Kashier Webhook Error: Order $order_id not found.");
			}

			echo 'received';

		} elseif ($this->request->server['REQUEST_METHOD'] === 'GET') {
			$data = $this->request->get;
			$data['payment_status'] = $this->request->get['paymentStatus'] ?? 'FAILURE';

			$merchantOrderId = $this->request->get['merchantOrderId'] ?? '';
			$order_id = (int) str_replace('ORD-9879-', '', $merchantOrderId);

			$order_info = $this->model_checkout_order->getOrder($order_id);

			if ($order_info) {
				if (isset($this->request->get['paymentStatus'])) {
					if ($this->request->get['paymentStatus'] === 'SUCCESS') {
						$this->model_extension_kashier_payment_kashier->preRedirect($data);
						$this->response->redirect($this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true));
					} else {
						$data['payment_status'] = 'FAILURE';
						$this->model_extension_kashier_payment_kashier->preRedirect($data);
						$this->response->redirect($this->url->link('checkout/failure', 'language=' . $this->config->get('config_language'), true));
					}
				}
			} else {
				$this->session->data['error'] = $this->language->get('error_invalid_order');
				$this->model_extension_kashier_payment_kashier->preRedirect($data);
				$this->response->redirect($this->url->link('checkout/failure', 'language=' . $this->config->get('config_language'), true));
			}
		} else {
			$this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 405 Method Not Allowed');
			$this->response->setOutput('Method "' . $this->request->server['REQUEST_METHOD'] . '" Not Allowed');
		}
	}