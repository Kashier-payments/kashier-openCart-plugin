<?php

$raw_payload = file_get_contents('php://input');
$json_data   = json_decode($raw_payload, true);

$data_obj = $json_data['data'];
$event    = $json_data['event'];

// Sort signature keys
sort($data_obj['signatureKeys']);

// Get headers
$headers = getallheaders();

// Lowercase all header keys
$headers = array_change_key_case($headers);

// Extract Kashier signature header
$kashierSignature = $headers['x-kashier-signature'];

// Build data array based on signature keys
$data = [];

foreach ($data_obj['signatureKeys'] as $key) {
    $data[$key] = $data_obj[$key];
}

// Build query string
$queryString = http_build_query(
    $data,
    '',
    '&',
    PHP_QUERY_RFC3986
);

// Generate signature
$signature = hash_hmac(
    'sha256',
    $queryString,
    $paymentApiKey,
    false
);

// Validate signature
if ($signature == $kashierSignature) {
    // do some actions
    echo 'valid signature';
    http_response_code(200);
} else {
    echo 'invalid signature';
    die();
}