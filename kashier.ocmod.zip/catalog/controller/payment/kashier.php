<?php
namespace Opencart\Catalog\Controller\Extension\Kashier\Payment;

use Opencart\Catalog\Model\Extension\Kashier\Payment\kashier as PaymentKashier;

class kashier extends \Opencart\System\Engine\Controller
{
	/**
	 * Index
	 *
	 * @return string
	 */
	public function index(): string
	{
		$this->load->language('extension/kashier/payment/kashier');

		$data['language'] = $this->config->get('config_language');

		return $this->load->view('extension/kashier/payment/kashier', $data);
	}


	public function confirm(): void
	{
		$this->load->language('extension/kashier/payment/kashier');
		$json = [];

		// Validate order
		if (!isset($this->session->data['order_id'])) {
			$json['error']['warning'] = $this->language->get('error_order');
			$this->sendJson($json);
			return;
		}

		$order_id = $this->session->data['order_id'];
		$this->load->model('checkout/order');
		$order_info = $this->model_checkout_order->getOrder($order_id);

		if (!$order_info) {
			$json['error']['warning'] = $this->language->get('error_order');
			$this->sendJson($json);
			return;
		}

		// Log selected payment method
		$this->log->write("Selected payment method: " . print_r($this->session->data['payment_method'], true));

		// Fetch merchant config
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "kashier_merchant_configs`");
		$config = $query->row;
		$this->log->write("config: " . print_r($config, true));

		// Determine selected method
		$selectedMethod = $this->getSelectedMethodFromSession();

		// Prepare payload
		$amount = $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
		$payload = [
			"maxFailureAttempts" => 1,
			"paymentType"       => "credit",
			"amount"            => (string)$amount,
			"currency"          => "egp",
			"order"             => "ORD-" ."".time()."-". $order_id,
			"failureRedirect"   => "false",
			"merchantId"        => $config["mid"],
			"merchantRedirect"  => $this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true),
			"display"           => "en",
			"type"              => "one-time",
			"allowedMethods"    => $selectedMethod,
			"description"       => "Payment for order ORD" . $order_id,
			"manualCapture"     => "false",
			"customer"          => [
				"email"     => $order_info['email'],
				"reference" => $order_info['email']
			],
			"enable3DS"         => "true",
			"serverWebhook"     => $this->url->link('extension/kashier/payment/kashier.callback', '', true),
		];

		// Determine API keys and base URL
		$isTestMode = ((int)$config['test_mode'] === 1);
		$secretKey = $isTestMode ? $config['test_secret_key'] : $config['live_secret_key'];
		$apiKey    = $isTestMode ? $config['test_api_key'] : $config['live_api_key'];
		$baseUrl   = $isTestMode ? PaymentKashier::TEST_API_BASE_URL : PaymentKashier::LIVE_API_BASE_URL;

		// Log payload for debugging
		$this->log->write("Kashier request payload: " . print_r($payload, true));
		$this->log->write("Kashier API URL: $baseUrl/payment/sessions");

		// Execute cURL request
		$response = $this->sendCurlRequest($baseUrl . '/payment/sessions', $payload, $secretKey, $apiKey);
		$this->log->write('Kashier payment session response: ' . $response);

		$result = json_decode($response, true);

		if (!empty($result['sessionUrl'])) {
			$json['redirect'] = $result['sessionUrl'];
			$this->model_checkout_order->addHistory(
				$order_id,
				$this->config->get('config_order_status_id'),
				'Kashier Payment Initiated',
				true
			);
		} else {
			$json['error']['warning'] = 'Unable to initiate payment. Please try again.';
		}

		$this->sendJson($json);
	}

	/**
	 * Helper to parse selected payment method from session
	 */
	private function getSelectedMethodFromSession(): string
	{
		$paymentCode = $this->session->data['payment_method']['code'] ?? '';
		if (strpos($paymentCode, 'kashier.') !== 0) {
			return '';
		}

		$method = str_replace('kashier.', '', $paymentCode);
		$map = [
			'card_enabled'              => 'card',
			'wallet_enabled'            => 'wallet',
			'bank_installments_enabled' => 'installments',
			'bnpls_enabled'             => 'bnpl'
		];

		return $map[$method] ?? '';
	}

	/**
	 * Helper to send JSON response
	 */
	private function sendJson(array $data): void
	{
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($data));
	}

	/**
	 * Helper to execute cURL request
	 */
	private function sendCurlRequest(string $url, array $payload, string $secretKey, string $apiKey): string
	{
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: ' . $secretKey,
			'api-key: ' . $apiKey,
			'Content-Type: application/json'
		]);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		$response = curl_exec($ch);
		curl_close($ch);
		return $response;
	}

	/**
	 * Callback
	 *
	 * Handles response from Kashier (both Webhook and Redirect)
	 *
	 * @return void
	 */
	public function callback(): void
	{
		$this->load->language('extension/kashier/payment/kashier');
		$this->load->model('extension/kashier/payment/kashier');
		$this->load->model('checkout/order');

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "kashier_merchant_configs` ORDER BY `date_added` DESC LIMIT 1");
		$config = $query->row;

		if (!$config) {
			$this->log->write('Kashier Callback Error: Merchant configuration not found.');
			return;
		}

		$isTestMode = ((int) $config['test_mode'] === 1);
		$secret = trim($isTestMode ? $config['test_secret_key'] : $config['live_secret_key']);
		$apiKey = trim($isTestMode ? $config['test_api_key'] : $config['live_api_key']);
		$mid    = trim($config['mid'] ?? '');

		if ($this->request->server['REQUEST_METHOD'] === 'POST') {
			$this->log->write('Kashier Webhook Received');

			$rawBody = file_get_contents('php://input');
			$json_data = json_decode($rawBody, true);

			$this->log->write("Kashier Webhook Payload: " . $rawBody);

			if (!$json_data || !isset($json_data['data']) || !isset($json_data['event'])) {
				$this->log->write('Kashier Webhook Error: Invalid JSON data.');
				return;
			}

			$data_obj = $json_data['data'];
			$event = $json_data['event'];

			// Sort signature keys alphabetically
			sort($data_obj['signatureKeys']);

			$parts = [];

			foreach ($data_obj['signatureKeys'] as $key) {
				if (!array_key_exists($key, $data_obj)) {
					$this->log->write("Kashier Webhook Warning: Missing key in payload: $key");
					continue;
				}

				$value = $data_obj[$key];
				
				// Documentation: Ensure that only the values of the keys are URL-encoded
				// Space should be %20 (rawurlencode)
				$parts[] = $key . '=' . rawurlencode((string)$value);
			}

			$queryString = implode('&', $parts);

			// Received Signature from Header
			$receivedSignature = trim($this->request->server['HTTP_X_KASHIER_SIGNATURE'] ?? '');
			
			// According to Documentation:
			// 1. Order signatureKeys alphabetically (already done via sort)
			// 2. Build queryString: key=rawurlencode(value)&...
			// 3. HMAC using Payment API Key
			$expectedSignature = hash_hmac('sha256', $queryString, $apiKey);

			if (!hash_equals($expectedSignature, $receivedSignature)) {
				$this->log->write('Kashier Webhook Error: Signature mismatch.');
				$this->log->write('Expected: ' . $expectedSignature);
				$this->log->write('Received: ' . $receivedSignature);
				return;
			}

			$this->log->write('Kashier Webhook Success: Signature validated.');

			

			// $data_obj = $json_data['data'];
			// $event = $json_data['event'];

			// if (!isset($data_obj['signatureKeys']) || !is_array($data_obj['signatureKeys'])) {
			// 	$this->log->write('Kashier Webhook Error: signatureKeys missing.');
			// 	return;
			// }
			// // Sort signature keys
			// sort($data_obj['signatureKeys']);

			// // Get headers
			// $kashierSignature = $this->request->server['HTTP_X_KASHIER_SIGNATURE'] ?? '';
			// $this->log->write('Header Signature: ' . $kashierSignature);
			

			// // Signature Validation
			// $data = [];
			// foreach ($data_obj['signatureKeys'] as $key) {
			// 	$data[$key] = $data_obj[$key];
			// }

			// $queryString = http_build_query($data, '', '&', PHP_QUERY_RFC3986);
			// $signature=hash_hmac('sha256',$queryString,$secret,false);

			// // $signature = $this->model_extension_kashier_payment_kashier->validateSignature($queryString, $secret);
			// // $kashierSignature = $this->request->server['HTTP_X_KASHIER_SIGNATURE'] ?? '';
			// // kashier verification
			// $this->log->write('Computed Signature: ' . $signature);
			
			// // foreach ($data_obj['signatureKeys'] as $key) {
			// // 	$value = $data_obj[$key];

			// // 	// 🔧 Normalize known problematic fields
			// // 	if ($key === 'channel') {
			// // 		$value = str_replace(' | ', '|', $value);
			// // 	}

			// // 	$data[$key] = $value;
			// // }

			// // if ($signature !== $kashierSignature) {
			// $this->log->write("signature ".$signature);
			// $this->log->write(" kashierSignature ". $kashierSignature);
			// $this->log->write("hash_equals(signature, kashierSignature) ".$signature== $kashierSignature);
			// if (!hash_equals($signature, $kashierSignature)) {
			// 	$this->log->write('Kashier Webhook Error: HMAC Failed to validate.');
			// 	return;
			// }

			// Extract Order ID
			$merchantOrderId = $data_obj['merchantOrderId'] ?? '';
			$parts = explode('-', $merchantOrderId);
			$order_id = $parts[2] ?? null;
			$this->log->write("order_id" . $order_id);
			$order_info = $this->model_checkout_order->getOrder($order_id);
			
			if ($order_info) {
				if ($event === 'pay') {
					if (strtoupper($data_obj['status']) === 'SUCCESS') {
						$order_status_id = $this->config->get('payment_kashier_processed_status_id');
						$this->log->write("order_status_id " . $order_status_id);
						
						// Check if already updated
						$histories = $this->model_extension_kashier_payment_kashier->getOrderHistories($order_id, 0, 100);
						foreach ($histories as $history) {
							if ((int) $history['order_status_id'] === (int) $order_status_id) {
								$this->log->write("Kashier Webhook: Order $order_id already updated to processed status.");
								return;
							}
						}
								
						$comment = sprintf($this->language->get('text_transaction_id'), $data_obj['transactionId'] ?? '') . '<br/>' . sprintf($this->language->get('text_merchant_id'), $merchantOrderId);	
						$this->log->write("comment: " . $comment);
						$this->model_extension_kashier_payment_kashier->addOrderHistory($order_id, $order_status_id, $comment);
						
					} else {
						$order_status_id = $this->config->get('payment_kashier_failed_status_id');
						$this->model_extension_kashier_payment_kashier->addOrderHistory($order_id, $order_status_id);
					}
				} else if ($event === 'refund') {
					if (strtoupper($data_obj['status']) === 'SUCCESS') {
						$comment = sprintf($this->language->get('text_transaction_id'), $data_obj['transactionId'] ?? '') . '<br/>' . sprintf($this->language->get('text_merchant_id'), $merchantOrderId);
						$order_status_id = $this->config->get('payment_kashier_refunded_status_id');
						$this->model_extension_kashier_payment_kashier->addOrderHistory($order_id, $order_status_id, $comment);
					}
				}
			} else {
				$this->log->write("Kashier Webhook Error: Order $order_id not found.");
			}

			echo 'received';

		} elseif ($this->request->server['REQUEST_METHOD'] === 'GET') {
			$data = $this->request->get;
			$data['payment_status'] = $this->request->get['paymentStatus'] ?? 'FAILURE';

			$merchantOrderId = $this->request->get['merchantOrderId'] ?? '';
			$order_id = (int) str_replace('ORD-9879-', '', $merchantOrderId);

			$order_info = $this->model_checkout_order->getOrder($order_id);

			if ($order_info) {
				if (isset($this->request->get['paymentStatus'])) {
					if ($this->request->get['paymentStatus'] === 'SUCCESS') {
						$this->model_extension_kashier_payment_kashier->preRedirect($data);
						$this->response->redirect($this->url->link('checkout/success', 'language=' . $this->config->get('config_language'), true));
					} else {
						$data['payment_status'] = 'FAILURE';
						$this->model_extension_kashier_payment_kashier->preRedirect($data);
						$this->response->redirect($this->url->link('checkout/failure', 'language=' . $this->config->get('config_language'), true));
					}
				}
			} else {
				$this->session->data['error'] = $this->language->get('error_invalid_order');
				$this->model_extension_kashier_payment_kashier->preRedirect($data);
				$this->response->redirect($this->url->link('checkout/failure', 'language=' . $this->config->get('config_language'), true));
			}
		} else {
			$this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 405 Method Not Allowed');
			$this->response->setOutput('Method "' . $this->request->server['REQUEST_METHOD'] . '" Not Allowed');
		}
	}
}
