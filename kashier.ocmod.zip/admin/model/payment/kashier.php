<?php
namespace Opencart\Admin\Model\Extension\Kashier\Payment;
/**
 * Kashier
 *
 * Can be called from $this->load->model('extension/kashier/payment/kashier');
 *
 * @package Opencart\Admin\Model\Extension\Kashier\Payment
 */
class kashier extends \Opencart\System\Engine\Model
{
	/**
	 * Install
	 *
	 * @return void
	 */
	public function install(): void
	{
		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "kashier_order` (
			`kashier_order_id` int(11) NOT NULL AUTO_INCREMENT,
			`order_id` int(11) NOT NULL,
			`kashier_tx_id` varchar(255) NOT NULL,
			`method` varchar(64) NOT NULL,
			`status` varchar(64) NOT NULL,
			`date_added` datetime NOT NULL,
			PRIMARY KEY (`kashier_order_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
		");

		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "kashier_merchant_configs` (
			`kashier_merchant_config_id` int(11) NOT NULL AUTO_INCREMENT,
			`mid` varchar(40) NOT NULL,
			`test_mode` boolean NOT NULL default(true),
			`test_api_key` varchar(100) NOT NULL,
			`live_api_key` varchar(100),
			`test_secret_key` text NOT NULL,
			`live_secret_key` text,
			`card_enabled` boolean NOT NULL default(false),
			`wallet_enabled` boolean NOT NULL default(false),
			`bank_installments_enabled` boolean NOT NULL default(false),
			`bnpls_enabled` boolean NOT NULL default(false),
			`date_added` datetime NOT NULL,
			PRIMARY KEY (`kashier_merchant_config_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
		");

		$this->db->query("CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "kashier_payment_report` (
			`kashier_payment_report_id` int(11) NOT NULL AUTO_INCREMENT,
			`order_id` int(11) NOT NULL,
			`method` varchar(64) NOT NULL,
			`amount` decimal(15,4) NOT NULL,
			`response` tinyint(1) NOT NULL,
			`date_added` datetime NOT NULL,
			PRIMARY KEY (`kashier_payment_report_id`)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci
		");
	}

	/**
	 * Uninstall
	 *
	 * @return void
	 */
	public function uninstall(): void
	{
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "kashier_order`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "kashier_merchant_configs`");
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "kashier_payment_report`");
	}

	/**
	 * Get Merchant Config
	 *
	 * @return array
	 */
	public function getMerchantConfig(): array
	{
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "kashier_merchant_configs` ORDER BY `date_added` DESC LIMIT 1");

		if ($query->num_rows) {
			return $query->row;
		}
		else {
			return [];
		}
	}

	/**
	 * Edit Merchant Config
	 *
	 * @param array $data
	 * @return void
	 */
	public function editMerchantConfig(array $data): void
	{
		$this->db->query("DELETE FROM `" . DB_PREFIX . "kashier_merchant_configs` ");

		$this->db->query("INSERT INTO `" . DB_PREFIX . "kashier_merchant_configs` SET 
			`mid` = '" . $this->db->escape($data['mid']) . "', 
			`test_mode` = '" . (int)$data['test_mode'] . "', 
			`test_api_key` = '" . $this->db->escape($data['test_api_key']) . "', 
			`live_api_key` = '" . $this->db->escape($data['live_api_key'] ?? '') . "', 
			`test_secret_key` = '" . $this->db->escape($data['test_secret_key']) . "', 
			`live_secret_key` = '" . $this->db->escape($data['live_secret_key'] ?? '') . "', 
			`card_enabled` = '" . (int)$data['card_enabled'] . "', 
			`wallet_enabled` = '" . (int)$data['wallet_enabled'] . "', 
			`bank_installments_enabled` = '" . (int)$data['bank_installments_enabled'] . "', 
			`bnpls_enabled` = '" . (int)$data['bnpls_enabled'] . "', 
			`date_added` = NOW()
		");
	}
}
