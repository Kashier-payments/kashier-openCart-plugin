<?php
namespace Opencart\Admin\Controller\Extension\Kashier\Payment;
class kashier extends \Opencart\System\Engine\Controller
{
	/**
	 * Index
	 *
	 * @return void
	 */
	public function index(): void
	{
		$this->load->language('extension/kashier/payment/kashier');

		$this->document->setTitle($this->language->get('heading_title'));

		$data['breadcrumbs'] = [];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'])
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment')
		];

		$data['breadcrumbs'][] = [
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/kashier/payment/kashier', 'user_token=' . $this->session->data['user_token'])
		];

		$data['save'] = $this->url->link('extension/kashier/payment/kashier.save', 'user_token=' . $this->session->data['user_token']);
		$data['back'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment');

		// Credentials & General Settings
		$data['mid'] = $this->config->get('payment_kashier_mid') ?: '';
		$data['test_mode'] = $this->config->get('payment_kashier_mode') ?? 1;
		$data['test_api_key'] = $this->config->get('payment_kashier_test_api_key') ?: '';
		$data['live_api_key'] = $this->config->get('payment_kashier_live_api_key') ?: '';
		$data['test_secret_key'] = $this->config->get('payment_kashier_test_secret_key') ?: '';
		$data['live_secret_key'] = $this->config->get('payment_kashier_live_secret_key') ?: '';
		
		// Payment Methods Toggles
		$data['card_enabled'] = $this->config->get('payment_kashier_card_enabled') ?? 0;
		$data['wallet_enabled'] = $this->config->get('payment_kashier_wallet_enabled') ?? 0;
		$data['bank_installments_enabled'] = $this->config->get('payment_kashier_bank_installments_enabled') ?? 0;
		$data['bnpls_enabled'] = $this->config->get('payment_kashier_bnpls_enabled') ?? 0;

		// Extension status and sort order
		// 'payment_kashier_card_debug',
        // 'payment_kashier_card_failed_status_id',
        // 'payment_kashier_card_pending_status_id',
        // 'payment_kashier_card_refunded_status_id',
        // 'payment_kashier_card_processed_status_id',
        // 'payment_kashier_card_geo_zone_id'
		$data['failed_status_id'] = $this->config->get('payment_kashier_card_failed_status_id');
		$data['pending_status_id'] = $this->config->get('payment_kashier_card_pending_status_id');
		$data['refunded_status_id'] = $this->config->get('payment_kashier_card_refunded_status_id');
		$data['processed_status_id'] = $this->config->get('payment_kashier_card_processed_status_id');
		$data['status'] = $this->config->get('payment_kashier_status');
		$data['sort_order'] = $this->config->get('payment_kashier_sort_order');

		$this->load->model('localisation/order_status');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		$this->load->language('extension/kashier/payment/kashier');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/kashier/payment/kashier', $data));
	}

	/**
	 * Save
	 *
	 * @return void
	 */
	public function save(): void
	{
		$this->load->language('extension/kashier/payment/kashier');

		$json = [];

		if (!$this->user->hasPermission('modify', 'extension/kashier/payment/kashier')) {
			$json['error'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['mid']) {
			$json['error']['merchant_id'] = $this->language->get('error_merchant_id');
		}

		if (!$json) {
			$this->load->model('setting/setting');

			$this->model_setting_setting->editSetting('payment_kashier', $this->request->post);

			// Save to custom table
			$this->load->model('extension/kashier/payment/kashier');

			$merchant_data = [
				'mid' => $this->request->post['mid'],
				'test_mode' => $this->request->post['mode'],
				'test_api_key' => $this->request->post['test_api_key'],
				'live_api_key' => $this->request->post['live_api_key'],
				'test_secret_key' => $this->request->post['test_secret_key'],
				'live_secret_key' => $this->request->post['live_secret_key'],
				'card_enabled' => $this->request->post['card_enabled'] ?? 0,
				'wallet_enabled' => $this->request->post['wallet_enabled'] ?? 0,
				'bank_installments_enabled' => $this->request->post['bank_installments_enabled'] ?? 0,
				'bnpls_enabled' => $this->request->post['bnpls_enabled'] ?? 0
			];

			$this->model_extension_kashier_payment_kashier->editMerchantConfig($merchant_data);

			$json['success'] = $this->language->get('text_success');
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	/**
	 * Install
	 *
	 * @return void
	 */
	public function install(): void
	{
		if ($this->user->hasPermission('modify', 'extension/payment')) {
			$this->load->model('extension/kashier/payment/kashier');

			$this->model_extension_kashier_payment_kashier->install();
		}
	}

	/**
	 * Uninstall
	 *
	 * @return void
	 */
	public function uninstall(): void
	{
		if ($this->user->hasPermission('modify', 'extension/payment')) {
			$this->load->model('extension/kashier/payment/kashier');

			$this->model_extension_kashier_payment_kashier->uninstall();
		}
	}
}
