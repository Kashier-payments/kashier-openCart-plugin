<?php
// Heading
$_['heading_title'] = 'Kashier';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified Kashier payment module!';
$_['text_edit'] = 'Edit Kashier';
$_['text_kashier'] = '<a href="https://www.kashier.io" target="_blank"><img src="../extension/kashier/admin/view/image/payment/kashier.png" alt="Kashier" title="Kashier" style="border: 1px solid #EEEEEE;" /></a>';

// Tabs
$_['tab_general'] = 'General';
$_['tab_methods'] = 'Payment Methods';

// Entry
$_['entry_mid'] = 'Merchant ID (MID)';
$_['entry_test_mode'] = 'Test Mode';
$_['entry_test_api_key'] = 'Test API Key';
$_['entry_live_api_key'] = 'Live API Key';
$_['entry_test_secret_key'] = 'Test Secret Key';
$_['entry_live_secret_key'] = 'Live Secret Key';
$_['entry_card_enabled'] = 'Card Enabled';
$_['entry_wallet_enabled'] = 'Wallet Enabled';
$_['entry_bank_installments_enabled'] = 'Bank Installments Enabled';
$_['entry_bnpls_enabled'] = 'BNPLs Enabled';
$_['entry_debug'] = 'Debug Mode';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['entry_failed_status'] = 'Order Failed Status';
$_['entry_pending_status'] = 'Order Pending Status';
$_['entry_processed_status'] = 'Order Successful Status';
$_['entry_refunded_status'] = 'Order Refund Status';

// Help
$_['help_debug'] = 'Logs requests and responses to the system log.';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Kashier!';
$_['error_merchant_id'] = 'Merchant ID required!';
$_['error_api_key'] = 'API Key required!';
$_['error_secret_key'] = 'Secret Key required!';
